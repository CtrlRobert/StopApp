//  Stop!
//  Created by Macbook on 3/27/25.

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack(spacing: 30) {
                Image(systemName: "face.smiling.fill")
                    .resizable()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.purple)

                Text("Bienvenido a Stop!")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.center)
                
                Text("Usa tu mente, no solo tu pantalla")
                    .font(.system(size: 16, weight: .medium, design: .rounded))
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)

                NavigationLink(destination: ModoNinoView()) {
                    Label("Modo Niño", systemImage: "face.smiling")
                        .font(.system(size: 20, weight: .medium, design: .rounded))
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue.opacity(0.8))
                        .foregroundColor(.white)
                        .cornerRadius(16)
                }

                NavigationLink(destination: ModoPadreView()) {
                    Label("Modo Padre", systemImage: "person.crop.circle.badge.checkmark")
                        .font(.system(size: 20, weight: .medium, design: .rounded))
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.green.opacity(0.8))
                        .foregroundColor(.white)
                        .cornerRadius(16)
                }

                NavigationLink(destination: ComoPrevenir()) {
                    Label("Como prevenir?", systemImage: "lightbulb.fill")
                        .font(.system(size: 20, weight: .medium, design: .rounded))
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.orange.opacity(0.9))
                        .foregroundColor(.white)
                        .cornerRadius(16)
                }

                NavigationLink(destination: ConsejosView()) {
                    Label("Consejos", systemImage: "quote.bubble.fill")
                        .font(.system(size: 20, weight: .medium, design: .rounded))
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.yellow.opacity(0.9))
                        .foregroundColor(.black)
                        .cornerRadius(16)
                }
            }
            .padding()
        }
    }
}
