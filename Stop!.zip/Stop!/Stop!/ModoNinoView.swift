//
//  ModoNinoView.swift
//  Stop!
//
//  Created by Macbook on 3/29/25.
//


import SwiftUI

struct ModoNinoView: View {
    @State private var tiempoUsado = true

    var body: some View {
        VStack(spacing: 25) {
            Image(systemName: "hourglass.bottomhalf.fill")
                .resizable()
                .frame(width: 60, height: 60)
                .foregroundColor(.purple)

            Text("Modo Niño")
                .font(.system(size: 24, weight: .bold, design: .rounded))

            if tiempoUsado {
                Text("Has usado tu hora de hoy.")
                    .multilineTextAlignment(.center)
                NavigationLink(destination: JuegoDesbloqueoView()) {
                    Label("Desbloquear tiempo", systemImage: "puzzlepiece.fill")
                        .padding()
                        .background(Color.purple.opacity(0.8))
                        .foregroundColor(.white)
                        .cornerRadius(12)
                }
            } else {
                Text("Tienes tiempo para jugar.")
            }
        }
        .padding()
    }
}