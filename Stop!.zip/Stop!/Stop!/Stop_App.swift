//
//  Stop_App.swift
//  Stop!
//
//  Created by Macbook on 3/29/25.
//

//
//  Stop_App.swift
//  Stop!
//
//  Created by Macbook on 3/27/25.
//

import SwiftUI

@main
struct Stop_App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
