//
//  ModoPadreView.swift
//  Stop!
//
//  Created by Macbook on 3/29/25.
//


import SwiftUI

struct ModoPadreView: View {
    var body: some View {
        VStack(spacing: 25) {
            Image(systemName: "gearshape.fill")
                .resizable()
                .frame(width: 60, height: 60)
                .foregroundColor(.green)

            Text("Modo Padre")
                .font(.system(size: 24, weight: .bold, design: .rounded))

            Text("Aquí podrás configurar apps y tiempos. (Simulado)")
                .multilineTextAlignment(.center)
        }
        .padding()
    }
}