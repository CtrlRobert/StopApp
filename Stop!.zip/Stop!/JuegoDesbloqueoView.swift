//
//  JuegoDesbloqueoView.swift
//  Stop!
//
//  Created by Macbook on 3/29/25.
//


import SwiftUI

struct JuegoDesbloqueoView: View {
    @State private var respuestaCorrecta = false
    @State private var respuestaIncorrecta = false

    var body: some View {
        VStack(spacing: 25) {
            Image(systemName: "gamecontroller.fill")
                .resizable()
                .frame(width: 60, height: 60)
                .foregroundColor(.purple)

            Text("Ejercicio para desbloquear")
                .font(.system(size: 22, weight: .bold, design: .rounded))

            Text("Había una vez un perro y un gato. El perro era muy juguetón.")
                .padding()
                .multilineTextAlignment(.center)

            Text("¿Quién era juguetón?")
                .font(.headline)

            HStack(spacing: 20) {
                Button("El perro") {
                    respuestaCorrecta = true
                    respuestaIncorrecta = false
                }
                .padding()
                .background(Color.green.opacity(0.8))
                .foregroundColor(.white)
                .cornerRadius(12)

                Button("El gato") {
                    respuestaCorrecta = false
                    respuestaIncorrecta = true
                }
                .padding()
                .background(Color.red.opacity(0.8))
                .foregroundColor(.white)
                .cornerRadius(12)
            }

            if respuestaCorrecta {
                Text("✅ Correcto. Has desbloqueado 4 horas para el fin de semana.")
                    .foregroundColor(.green)
                    .font(.system(size: 18, weight: .medium, design: .rounded))
                    .multilineTextAlignment(.center)
            }

            if respuestaIncorrecta {
                Text("❌ Ups, intenta de nuevo.")
                    .foregroundColor(.red)
                    .font(.system(size: 18, weight: .medium, design: .rounded))
                    .multilineTextAlignment(.center)

                Button("Reintentar") {
                    respuestaCorrecta = false
                    respuestaIncorrecta = false
                }
                .padding()
                .background(Color.orange.opacity(0.8))
                .foregroundColor(.white)
                .cornerRadius(12)
            }
        }
    }
}