//
//  ConsejoCard.swift
//  Stop!
//
//  Created by Macbook on 3/29/25.
//


import SwiftUI

struct ConsejoCard: View {
    let titulo: String
    let texto: String
    let icono: String
    let color: Color

    var body: some View {
        VStack(spacing: 10) {
            Image(systemName: icono)
                .resizable()
                .scaledToFit()
                .frame(height: 40)
                .foregroundColor(.white)

            Text(titulo)
                .font(.title2)
                .bold()
                .foregroundColor(.white)

            Text(texto)
                .font(.body)
                .multilineTextAlignment(.center)
                .foregroundColor(.white)
        }
        .padding()
        .frame(width: 200, height: 180)
        .background(color)
        .cornerRadius(20)
        .shadow(radius: 5)
    }
}

struct ConsejosView: View {
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 20) {
                ConsejoCard(titulo: "Leer", texto: "Cada página es una sorpresa.", icono: "book.fill", color: .purple)
                ConsejoCard(titulo: "Aprender", texto: "Leer te hace más listo cada día.", icono: "graduationcap.fill", color: .blue)
                ConsejoCard(titulo: "Imaginar", texto: "En los libros hay héroes y dragones.", icono: "sparkles", color: .indigo)
                ConsejoCard(titulo: "Soñar", texto: "Leer es clave para aprender y soñar.", icono: "lightbulb.fill", color: .orange)
                ConsejoCard(titulo: "Moverte", texto: "Hacer ejercicio te da energía.", icono: "figure.walk", color: .green)
                ConsejoCard(titulo: "Cuidarte", texto: "Tu mente se siente mejor si te mueves.", icono: "brain.head.profile", color: .mint)
                ConsejoCard(titulo: "Crear", texto: "Dibujar y pintar te hace único.", icono: "paintbrush.fill", color: .pink)
                ConsejoCard(titulo: "Expresarte", texto: "La creatividad te ayuda a mostrar lo que sientes.", icono: "pencil.tip", color: .yellow)
            }
            .padding()
        }
        .navigationTitle("Consejos")
    }
}