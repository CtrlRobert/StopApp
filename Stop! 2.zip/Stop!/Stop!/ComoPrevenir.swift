//
//  ComoPrevenir.swift
//  Stop!
//
//  Created by Macbook on 3/29/25.
//


import SwiftUI

struct ComoPrevenir: View {
    var body: some View {
        VStack(spacing: 25) {
            Image(systemName: "book.fill")
                .resizable()
                .frame(width: 60, height: 60)
                .foregroundColor(.orange)

            Text("¡Cuídate de las redes sociales!.")
                .font(.system(size: 24, weight: .bold, design: .rounded))

            Text("Recuerda que las redes sociales y el consumo excesivo de pantallas no son apropiadas para niños porque pueden causar problemas de sueño, atención y sedentarismo.")
                .multilineTextAlignment(.center)

            Text("¿Qué puedes hacer para prevenir un uso excesivo?")
                .multilineTextAlignment(.center)

            Text("""
                 1.- Usa Stop con ayuda de tus padres para prevenir uso excesivo.
                 2.- Poner atención al tiempo que le dedicas a las redes sociales.
                 3.- Cuídate del contenido no apropiado en internet.
                 4.- Pasa tiempo de calidad con tu familia y amigos.
                 """)
        }
        .padding()
    }
}